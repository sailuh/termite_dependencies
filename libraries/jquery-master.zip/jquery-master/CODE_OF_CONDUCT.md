jQuery is a [JS Foundation](https://js.foundation/) project and subscribes to its code of conduct.

It is available at https://js.foundation/community/code-of-conduct.
